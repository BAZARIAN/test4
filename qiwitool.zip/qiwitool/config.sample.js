module.exports = {
  qiwi: {
    apiKey: '',
    publicUri: 'http://%INSERT_YOUR_UP%:9901/some-hook.php'
  },
  rest: {
    port: 9901
  },
  bonuses: [{
    minValue: 0,
    multiplier: 1
  }],
  shop: {
    storeID: '',
    serverID: '',
    serverKey: '',
  }
}