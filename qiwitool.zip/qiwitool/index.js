const Controller = require("./src/classes/Controller");

const controller = new Controller();