module.exports = {
  qiwi: {
    apiKey: '54a8e871a34868039319f10902789062',
    publicUri: 'http://171.33.253.118/some-hook.php'
  },
  rest: {
    port: 80
  },
  bonuses: [{
    minValue: 0,
    multiplier: 1
  }],
  shop: {
    storeID: '8160',
    serverID: '3768',
    serverKey: 'faf3f128077fa7f43a6e',
  }
}