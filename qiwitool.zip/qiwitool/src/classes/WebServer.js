const Controller = require('./Controller');

class WebServer {
  /**
   * Конструктор класса
   * @param {number} port 
   */
  constructor(port) {
    if (!port) {
      throw new Error('Не указан порт для запуска веб-сервера');
    }

    this.express = require('express')();
    this.express.use(require('body-parser').json());

    this.listenRoutes();

    this.express.listen(port, () => {
      console.log(`Запущен веб-сервер на 0.0.0.0:${port}`);
    });
  }

  /**
   * Прослушка событий
   */
  listenRoutes() {
    this.express.post('/some-hook.php', (req, res) => {
      Controller.instance.qiwi._alertGot = true;
      if (!req.body.payment) {
        return res.status(200);
      }

      const { comment, sum, txnId } = req.body.payment;
      
      Controller.instance.processPayment(txnId, sum.amount, comment);

      return res.status(200).json(true);
    });
  }
}

module.exports = WebServer;