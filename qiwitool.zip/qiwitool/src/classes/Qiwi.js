const { default: axios } = require('axios');

class Qiwi {
  /**
   * Базовый УРИ QIWI
   * @type {string}
   */
  static uri = 'https://edge.qiwi.com';

  /**
   * Конструктор класса
   * @param {string} apiKey 
   * @param {string} publicUrl
   */
  constructor(apiKey, publicUrl) {
    if (!apiKey || !publicUrl) {
      throw new Error('Не передан API ключ для QIWI');
    }

    this.apiKey = apiKey;
    this.publicUri = publicUrl;

    this._alertGot = false;
  }

  /**
   * Начальная настройка
   * @returns {Promise<boolean>}
   */
  async bootstrap() {
    const { hookId } = await this.getWebhooks();
    if (hookId) {
      const { response } = await this.removeWebhook(hookId);

      if (['Hook deleted'].includes(response)) {
        return await this.bootstrap();
      }

      console.log('Ошибка удаления существующего хука, проверьте данные...');
      console.log(response);
      return false;
    }

    await this.addWebhook();

    const { hookId: testHookId } = await this.getWebhooks();
    if (!testHookId) {
      console.log('Ошибка создания хука... Проверьте данные');
      return false;
    }

    const testAlertResult = await this.testAlert(testHookId);
    
    return true;
  }

  /**
   * Отправить тестовое оповещение
   * @returns {Promise<*>}
   */
  async testAlert(hookId) {
    try {
      console.log(`Получение ключа для проверки запросов...`);
      const { data } = await axios.get(`${Qiwi.uri}/payment-notifier/v1/hooks/${hookId}/key`, this.buildOptions());
      console.log(`Получен ключ для проверки запросов: ${data.key}`);

      const result = await axios.get(`${Qiwi.uri}/payment-notifier/v1/hooks/test`, this.buildOptions());
  
      console.log('Ожидание тестового оповещения...');
    
      await new Promise((res) => {
        const interval = setInterval(() => {
          if (this._alertGot) {
            clearInterval(interval);
            
            console.log('Получено тестовое оповещение, всё готово!');
            res(true);
          }
        }, 500);
      });

      return result.data;
    }
    catch(exc) {
      console.log(exc)
      return exc.response.data;
    }
  }

  /**
   * Получить список веб-хуков
   * @returns {Promise<*>}
   */
  async getWebhooks() {
    try {
      const result = await axios.get(`${Qiwi.uri}/payment-notifier/v1/hooks/active`, this.buildOptions());
  
      return result.data;
    }
    catch(exc) {
      return exc.response.data;
    }
  }

  /**
   * Зарегистрировать вебхук
   * @returns {Promise<boolean>}
   */
  async addWebhook() {
    const opts = this.buildOptions({
      hookType: 1,
      txnType: 0, 
      param: this.publicUri
    });

    try {
      const result = await axios.put(`${Qiwi.uri}/payment-notifier/v1/hooks`, null, opts);
  
      return result.data;
    }
    catch(exc) {
      return exc.response.data;
    }
  }

  /**
   * Удалить вебхук
   * @param {*} hookId 
   * @returns {Promise<*>}
   */
  async removeWebhook(hookId) {
    const opts = this.buildOptions();

    try {
      const result = await axios.delete(`${Qiwi.uri}/payment-notifier/v1/hooks/${hookId}`, opts);
  
      return result.data;
    }
    catch(exc) {
      console.log(exc)
      return exc.response.data;
    }
  }

  /**
   * Настройки для запроса
   * @param {Object|null} params 
   * @returns {Object}
   */
  buildOptions(params = {}) {
    return {
      params: params,
      headers: {
        'Authorization': `Bearer ${this.apiKey}`
      }
    }
  } 
}

module.exports = Qiwi;