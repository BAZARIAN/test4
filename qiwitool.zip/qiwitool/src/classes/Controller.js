const config = require("../../config");
const Qiwi = require("./Qiwi");

const { default: axios } = require('axios');

class Controller {
  /**
   * @type {Controller}
   */
  static instance = null;

  /**
   * Конструктор класса
   */
  constructor() {
    Controller.instance = this;

    const WebServer = require("./WebServer");

    this.server = new WebServer(config.rest.port);
    this.qiwi = new Qiwi(config.qiwi.apiKey, config.qiwi.publicUri);

    this.bootstrap();
  }

  /**
   * Запуск контроллера
   */
  async bootstrap() {
    const qiwiBootstrap = await this.qiwi.bootstrap();
    if (!qiwiBootstrap) {
      console.log('Не удалось взаимодействовать с QIWI API');
      return;
    }
  }

  /**
   * Провести платёж
   * @param {string} user 
   * @param {number} amount 
   * @param {string} comment 
   */
  async processPayment(user, amount, comment) {
    let message = `Получен платёж #${user} [${amount} рублей]. Комментарий: ${comment}`;
    comment = comment.replace('Пополнение баланса в магазине FADE RUST через Qiwi. Может занять некоторое время. Ваш ID: ', '');
    try {
      let shouldIncome = comment.length == 17 && !isNaN(+comment);
      if (shouldIncome) {
        let finalBalance = config.bonuses.sort((a,b) => b.minValue - a.minValue).find(v => amount > v.minValue);

        let finalAmount = finalBalance.multiplier * amount;
  
        const balance = await axios.get(`https://store-api.moscow.ovh/index.php`, {
          params: {
            steamID: comment,
            sum: finalAmount,
            modules: 'users',
            action: 'changeUserBalance',
            type: 'give',
            ...config.shop
          }
        });
  
        if (balance.data.status == 'success') {
          message += `\nУспешно пополнили баланс для пользователя на ${finalAmount} рублей`;
        }
        else {
          message += `\nНе удалось пополнить баланс, причина: ${balance.data}`;
        }
      }
      else {
        message += '\nНе удалось пополнить баланс, неверный SteamID';
      }
    }
    catch (e) {
      message += `\nНе удалось пополнить баланс, ошибка: ${e.toString()}`
    }

    console.log(message);
  }
}

module.exports = Controller;